from __future__ import annotations

from functools import lru_cache
from typing import List, Optional

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_prefix="DUQB_",
        extra="ignore",
    )

    app_name: str = "Question Bank API"
    environment: str = "development"
    debug: bool = False

    database_url: str = "sqlite:///./duqbank.db"

    secret_key: str = "dev-secret-change-me"
    device_token_salt: str = "device-token-v1"
    admin_session_secret: str = "dev-admin-session-change-me"

    cors_origins: List[str] = ["*"]

    rate_limit_per_minute: int = 120
    auth_rate_limit_per_minute: int = 20
    default_page_size: int = 25
    max_page_size: int = 100

    @field_validator("cors_origins", mode="before")
    @classmethod
    def _split_origins(cls, value: object) -> object:
        if isinstance(value, str):
            return [item.strip() for item in value.split(",") if item.strip()]
        return value

    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
